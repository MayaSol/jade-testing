import svg4everybody from 'svg4everybody';
import $ from 'jquery';
require('./range.js');
require('./about-text.js');

$(() => {
	svg4everybody();
});

